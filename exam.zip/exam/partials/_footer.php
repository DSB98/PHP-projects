<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

<style>
/*footer*/
.col_white_amrc { color:gray;}
footer { width:100%; background-color:#f1f2f7; min-height:100px; padding:10px 0px 25px 0px ;}
.pt2 { padding-top:40px ; margin-bottom:20px ;}
footer p { font-size:13px; color:#CCC; padding-bottom:0px; margin-bottom:8px;}
.mb10 { padding-bottom:15px ;}
.footer_ul_amrc { margin:0px ; list-style-type:none ; font-size:14px; padding:0px 0px 10px 0px ; }
.footer_ul_amrc li {padding:0px 0px 5px 0px;}
.footer_ul_amrc li a{ color:#CCC;}
.footer_ul_amrc li a:hover{ color:#fff; text-decoration:none;}
.fleft { float:left;}
.padding-right { padding-right:10px; }

.footer_ul2_amrc {margin:0px; list-style-type:none; padding:0px;}
.footer_ul2_amrc li p { display:table; }
.footer_ul2_amrc li a:hover { text-decoration:none;}
.footer_ul2_amrc li i { margin-top:5px;}

.bottom_border { border-bottom:1px solid #323f45; padding-bottom:10px;}
.foote_bottom_ul_amrc {
	list-style-type:none;
	padding:0px;
	display:table;
	margin-top: 10px;
	margin-right: auto;
	margin-bottom: 10px;
	margin-left: auto;
}
.foote_bottom_ul_amrc li { display:inline;}
.foote_bottom_ul_amrc li a { color:gray; margin:0 12px;}

.social_footer_ul { display:table; margin:15px auto 0 auto; list-style-type:none;  }
.social_footer_ul li { padding-left:20px; padding-top:10px; float:left; }
.social_footer_ul li a { color:gray; border:1px solid #CCC; padding:8px;border-radius:50%;}
.social_footer_ul li i {  width:20px; height:20px; text-align:center;}

.social_footer_ul2 { display:table; margin:15px auto 0 auto; list-style-type:none;  }
.social_footer_ul2 li { padding-top:5px; float:left; }
.social_footer_ul2 li a { color:#CCC; padding:8px;}
.social_footer_ul2 li i {  width:20px; height:20px; text-align:center;}
</style>
<center>
<!--footer starts from here-->
<footer class="footer">
<div class="container bottom_border">
<div class="row">






<div class=" col-sm-4 col-md  col-12 col">
<h5 class="headin5_amrc col_white_amrc pt2">Follow us</h5>
<!--headin5_amrc ends here-->

<ul class="social_footer_ul">
<li><a href=" https://www.facebook.com/YuvaShiledarSanstha/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
<li><a href=" https://twitter.com/YuvaShiledaar?s=09" target="_blank"><i class="fab fa-twitter"></i></a></li>
<!--<li><a href="" target="_blank"><i class="fab fa-linkedin"></i></a></li>-->
<li><a href="https://instagram.com/yuva_maharashtra?igshid=eu0gyezr1rqk" target="_blank"><i class="fab fa-instagram"></i></a></li>
</ul>
<!--footer_ul2_amrc ends here-->
</div>
</div>



<div class="container col-sm-4 col-md  col-12 col">
<ul class="foote_bottom_ul_amrc">
<li><a href="/exam">Home</a></li>
<li><a href="about.php">About</a></li>
<li><a href="privacypolicy.php">Privacy Policy</a></li>
</ul>
</div>

</div>
<!--foote_bottom_ul_amrc ends here-->
<p style="color:gray;">Designed by <a href="#">Alok Yadav</a></p>

<ul class="social_footer_ul2">
<li><a href="#"><i class="fab fa-facebook"></i></a></li>
<li><a href="#"><i class="fab fa-twitter"></i></a></li>
<li><a href="#"><i class="fab fa-linkedin"></i></a></li>
<li><a href="#"><i class="fab fa-instagram"></i></a></li>
</ul>
<!--social_footer_ul ends here-->
</footer>
<?php

?>
</center>
