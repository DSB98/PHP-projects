<?php
$servername="localhost";
$username="root";
$password="";
$database="result_management_2021_22";
$conn=mysqli_connect($servername,$username,$password,$database);
// $conn=mysqli_connect('localhost','root','','bloodbank');
?>