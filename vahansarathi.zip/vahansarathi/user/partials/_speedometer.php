<div id="speed-gauge">
 	 <div class="gauge">
            <div class="slice"></div>
            <div class="slice"></div>
            <div class="slice"></div>
            <div class="slice"></div>
            <div class="slice"></div>
            <div class="slice"></div>
            <div class="slice"></div>
            <div class="slice"></div>   
            <div class="slice"></div>   
            <div class="subslice"></div> 
            <div class="subslice"></div> 
            <div class="subslice"></div> 
            <div class="subslice"></div> 
            <div class="subslice"></div> 
            
            <div class="subslice"></div> 
            <div class="subslice"></div> 
            <div class="subslice"></div> 
          	<div class="rpm">0</div>
            <div class="rpm">1</div>
            <div class="rpm">2</div>
            <div class="rpm">3</div>
            <div class="rpm">4</div>
            <div class="rpm">5</div>
            <div class="rpm">6</div>
            <div class="rpm">7</div>
            <div class="rpm">8</div>
           
           <!--RPM Slice-->
           
           	<div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            <div class="rpmSlice"></div>
            
            
		 	<div class="rpmSpeed">0</div>
            <div class="rpmSpeed">30</div>
            <div class="rpmSpeed">60</div>
            <div class="rpmSpeed">90</div>
            <div class="rpmSpeed">120</div>
            <div class="rpmSpeed">150</div>
            <div class="rpmSpeed">180</div>
            <div class="rpmSpeed">210</div>
            <div class="rpmSpeed">240</div>
            <div class="rpmSpeed">270</div>
            <div class="rpmSpeed">300</div>
            <div class="rpmSpeed">330</div>
            <div class="rpmSpeed">360</div>
            <div class="rpmSpeed">390</div>
            <div class="rpmSpeed">420</div>
            <div class="rpmSpeed">450</div>
            <div class="rpmSpeed">480</div>
            <div class="rpmSpeed">km/h</div>
			
            <div id="sui"></div>
            <div id="SUICIRCLE" class="suiCircle"></div>
          	<div class="bottomStroke">
            	
            		<div class="speedplus">0</div>
            		<div style="position: absolute; left: 50%; top: 24%; ">
            		<div class="gear" style="color: orange">P</div>
            		<div class="gear" style="color: orangered">R</div>
            		<div class="gear" style="color: green">N</div>
            		<div id="dgear" class="gear" style="color: whitesmoke;font-size: 18px;margin-top: -6px;">D</div>
            		<div class="gear" style="color: coral">B</div>
                    </div>
                </div>
                     
    		<div class="gauge-circle-1"></div>
      </div>
	</div>
	
	<div id="" style="width:200px;margin: auto; margin-top:20px; ">
		<input type="text" style="width:90px" placeholder="Speed in Km/h" id="Give">
		<button id="SpeedCheck" class="btn-group-lg">Check Speed</button>
	</div>

    