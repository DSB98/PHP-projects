
function getBloodGroup() {
    var bGroup = document.getElementById("bgroup").value;
    alert("Hello! I am an alert box!");
}
function myFunction() {
  var x = document.getElementById("mySelect").value;
  document.getElementById("demo").innerHTML = "You selected: " + x;
}

function getRequirement() {
  alert("Hello! I am an alert box!")
    var requirement = document.getElementById("requirement").value;

}

function getPatientName() {
    var patientName = document.getElementById("name").value;
}

function getAge() {
    var age = document.getElementById("age").value;
    checkDetails();
}

function checkDetails() {
   
}
