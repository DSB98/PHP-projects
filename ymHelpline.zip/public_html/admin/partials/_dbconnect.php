<?php
$servername="localhost";
$username="u789522342_rootYM";
$password="root@YM2021";
$database="u789522342_bloodbank";
$conn=mysqli_connect($servername,$username,$password,$database);
// $conn=mysqli_connect('localhost','root','','bloodbank');
?>